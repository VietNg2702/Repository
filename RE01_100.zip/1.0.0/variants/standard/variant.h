
#ifndef _VARIANT_RENESAS_RE01
#define _VARIANT_RENESAS_RE01


#include <stdint.h>



/*----------------------------------------------------------------------------
*        Headers
*----------------------------------------------------------------------------*/

#include "Arduino.h"
#ifdef __cplusplus
#include "UARTClass.h"
#endif



#ifdef __cplusplus
extern UARTClass Serial;
#endif


#endif 
