/**
 * @file      demo_manager_transceiver.h
 *
 * @brief     Definition of the demonstration manager for a transceiver.
 *
 * Revised BSD License
 * Copyright Semtech Corporation 2020. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Semtech corporation nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL SEMTECH CORPORATION BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __DEMO_MANAGER_TRANSCEIVER_H__
#define __DEMO_MANAGER_TRANSCEIVER_H__

#include <stddef.h>
#include "demo_manager_interface.h"
#include "signaling_interface.h"
#include "timer_interface.h"
#include "lr1110_system.h"
#include "lr1110_bootloader.h"
#include "../connectivity/connectivity_manager_transceiver.h"

class DemoManagerTransceiver : public DemoManagerInterface
{
   public:
    DemoManagerTransceiver( DeviceTransceiver* device, EnvironmentInterface* environment,
                            AntennaSelectorInterface* antenna_selector, SignalingInterface* signaling,
                            TimerInterface* timer, CommunicationInterface* communication_interface,
                            ConnectivityManagerTransceiver* connectivity_manager );
    virtual ~DemoManagerTransceiver( );

    void  Start( demo_type_t demo_type ) override;
    void* GetResults( ) override;

   private:
    DeviceTransceiver* device;
};

#endif  // __DEMO_MANAGER_TRANSCEIVER_H__
