#ifndef _SYSTEM_CLOCK_H
#define _SYSTEM_CLOCK_H

#include "r_system_api.h"

#ifdef __cplusplus
extern "C" {
#endif

void system_clock_init( void );

#ifdef __cplusplus
}
#endif

#endif
