/*********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2018-2020 Renesas Electronics Corporation. All rights reserved.
**********************************************************************************************************************/

/*******************************************************************************
* System Name  :  sample software for current measurement
* File Name    : main.c
* Version      : 1.00
* Device       : RE01 256KB
* Abstract     : Demo source file
* Tool-Chain   : IAR compiler v8.40.2  and GCC ARM Embedded v6.3.1.20170620
* IDE          : IAR EWARM and Renesas e2 studio
* OS           : not use
* H/W Platform : Evaluation Kit RE01 256KB
* Description  : This sample code shows power modes and clock settings in MIP LCD display.
* 				 This sample code is intended to assist current consumption measurement.
* 				 When used together with current measurement tool, users can easily see current consumption of different modes and clock settings of RE01 256KB Group product.
* Limitation   : none
*******************************************************************************/

#include "RE01_256KB.h"
#include "r_core_cfg.h"
#include "r_system_api.h"
#include "r_lpm_api.h"

/* Start user code for include. */
#include "r_smip_api.h"
#include "r_image.h"
#include "nop_func.h"

/* End user code.*/

/***********************************************************************************************************************
Macros
***********************************************************************************************************************/

/* display potition for SMIP */
#define SETLINE_MODE    140    
#define SETLINE_CLOCK   167 
#define SETLINE_ICLK    194
#define SETLINE_PCLKB   221

/* the whole states enum */
typedef enum{
  BOOST_ALLPWON,
  ALLPWON,
  MINPWON,
  VBB_MINPWON,
  SSTBY_VBB_MINPWON,
  DSTBY
}whole_state_t;

/* boost_allpwon enum */
typedef enum{
  BOOST_ALLPWON1, /*HOCO 64 MHz*/
  BOOST_ALLPWON2  /*HOCO 32 MHz*/
}boostallpwon_state_t;

/* allpwon enum */
typedef enum{
  ALLPWON1,     /*MOSC 32 MHz HS*/
  ALLPWON2,     /*MOSC 16 MHz HS*/
}allpwon_state_t;

/* minpwon enum */
typedef enum{
  MINPWON1,     /*MOSC 32 MHz HS*/
  MINPWON2,     /*MOSC 16 MHz HS*/
  MINPWON3,     /*MOCO 2 MHz LS*/
  MINPWON4      /*MOCO 1 MHz LS*/
}minpwon_state_t;

/* vbb_pwon enum */
typedef enum{
  VBB_MINPWON1  /*SOSC 32 kHz*/
}vbb_minpwon_state_t;

/* sstby_vbb_pwon enum */
typedef enum{
  SSTBY_VBB_MINPWON1    /*SOSC 32 kHz*/
}sstby_vbb_minpwon_state_t;

/* dstby enum */
typedef enum{
  DSTBY1,    /*WUPT ON*/
}dstby_state_t;



/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
void initialize(void);

/* whole process */
void whole_process(void)             __attribute__ ((section(".ramfunc"))) __attribute__ ((noinline));

/* boost_allpwon functions */
void trans_boost_allpwon(void) __attribute__ ((section(".ramfunc"))) __attribute__ ((noinline));

/* allpwon functions */
void trans_allpwon(void) __attribute__ ((section(".ramfunc"))) __attribute__ ((noinline));

/* minpwon functions */
void trans_minpwon(void)         __attribute__ ((section(".ramfunc"))) __attribute__ ((noinline));

/* vbb_minpwon functions */
void trans_vbb_minpwon(void)     __attribute__ ((section(".ramfunc"))) __attribute__ ((noinline));

/*vbb minpwon SSTBY function*/
void trans_sstby_vbb_minpwon(void) __attribute__ ((section(".ramfunc"))) __attribute__ ((noinline));

/*deep software standby function*/
void trans_dstby(void) __attribute__ ((section(".ramfunc"))) __attribute__ ((noinline));

/*SMIP function*/
void trans_MIP_sequence(uint32_t next_target,uint32_t next_target_ditail) __attribute__ ((section(".ramfunc"))) __attribute__ ((noinline));
void make_img(uint32_t next_target,uint32_t next_target_ditail) __attribute__ ((section(".ramfunc"))) __attribute__ ((noinline));
void set_data(char target[],uint8_t line) __attribute__ ((section(".ramfunc"))) __attribute__ ((noinline));

/*flag for SMIP transfer success/fail*/
volatile uint8_t f_disp_end = 0;

/* End user code. */

/**********************************************************************************************************************/
/* api call back function */
/**********************************************************************************************************************/
void smip_cb(uint32_t event)
{
    f_disp_end = 1;
}

/***********************************************************************************************************************
* Function Name: main
* Revision     : 1.00
* Description  : main function. Please add the code for your system.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
int main()
{
  /**** It recommends use this part as template this device's start-up code. ****/
  /* If the API functions are allocated to RAM, this function must be executed first */
  /* It copies Driver codes, which change the allocation area from ROM to RAM, by using r_[module]_cfg.h */ 
  /* Attention: Every code Pin.c is always allocated to RAM. These functions are called from API.  */
  R_SYS_CodeCopy();
  /* Initialize System Function Driver. */
  /* This function needs to be called after R_SYS_CodeCopy function. */
  R_SYS_Initialize();
  /* Initialize LPM Function Driver. */
  /* This function needs to be called before call R_LPM_IOPowerSupplyModeSet function. */
  R_LPM_Initialize();
  /* Set Power Supply Open Control Register (VOCR register)                                      */
  /* If you doesn't clear bits which corresponding your using port domains, MCU cannot read      */
  /* correctly value of input signal.                                                            */ 
  /* The VOCR register is used for control such that, when power is not being supplied to        */
  /* the AVCC0, IOVCC0,IOVCC1.                                                                  ,*/
  /* Thie feature is mainly usign when the device is Energy Harvesting start-up.                 */
  /* Default value is "NOT propagated" signal into internal device.                              */
  /* Please change the value of argument with your target board                                  */
  R_LPM_IOPowerSupplyModeSet(0xF2);
  /**** End of template code.   ****/

  /*******************************************************************/
  /**** Write user code for user init and system operations here. ****/
  /*******************************************************************/


  initialize();
  whole_process();

  return 0;
}


/***********************************************************************************************************************
* Function Name: trans_MIP_sequence
* Description  : Function to show display in MIP LCD
* Arguments    : next_target: target power mode
*                next_target_ditail: target clock frequency
* Return Value : none
***********************************************************************************************************************/
void trans_MIP_sequence(uint32_t next_target,uint32_t next_target_ditail)
{
      int32_t gs_ret = 0;
      e_smip_err_t result;                      /*variable to check status of SMIP function*/
      
      /*restart AGT*/
      SYSC->MSTPCRA_b.MSTPA22=0;
      MSTP->MSTPCRD_b.MSTPD3=0;  
      AGT0->AGTCR_b.TSTART=1;      
      while(1!=AGT0->AGTCR_b.TCSTF);    
      AGT0->AGTMR2_b.LPM=1;
      while(1!=AGT0->AGTMR2_b.LPM);
      
            
      /* if next_target is not ALLPWON or BOOST_ALLPWON, switch to ALLPWON mode */
      if(ALLPWON!=next_target && BOOST_ALLPWON!=next_target)
      {
        gs_ret = R_SYS_HighSpeedModeSet(); /* set high speedmode */
          
        R_SYS_MainOscSpeedClockStart(); /*Start MOSC*/
        while(1 != SYSC->OSCSF_b.MOSCSF)
        {
          /* Waiting of MOSC oscillation stabilization */
        }
        
        gs_ret = R_SYS_SystemClockMOSCSet();	/* set MOSC as System Clock */
        if(0 != gs_ret)
        {
          while(1);
        }
                
        /*change clock division to 4 MHz to enter ALLPWON mode*/
        SYSC->PRCR = 0xA501;              /* PRCR0 is Disable */
        SYSC->SCKDIVCR_b.PCKB=6; 
        SYSC->SCKDIVCR_b.ICK=3;         
        SYSC->PRCR = 0xA500;              /* PRCR0 is Enabled */
        
        R_LPM_PowerSupplyModeAllpwonSet();
        
        SYSC->PRCR = 0xA501;              /* PRCR0 is Disable */
        SYSC->SCKDIVCR_b.ICK=0; 
        SYSC->PRCR = 0xA500;              /* PRCR0 is Enabled */
      }     

      /**display in SMIP**/  
      make_img(next_target,next_target_ditail); /* make image data  */          
            
      R_SMIP_Resume(1000000);                   /* resume SMIP driver */      
      
      result=R_SMIP_Send(0, 256, bgimg);        /* Update image */
      while(SMIP_OK != result);
      
      while(0 == f_disp_end);                  /* Wait for transmission completion */
      f_disp_end = 0;                           /* f_disp_end flag reset */
      
      if(DSTBY==next_target)
      {
        R_SYS_SoftwareDelay(3000, SYSTEM_DELAY_UNITS_MILLISECONDS); 
        
        result=R_SMIP_Send(0, 256, warning);        /* Update image */
        while(SMIP_OK != result);
        
        while(0 == f_disp_end);                  /* Wait for transmission completion */
        f_disp_end = 0;                           /* f_disp_end flag reset */
  
      }

      
      R_SMIP_Suspend();   
      while(SMIP_OK != result);
      
      /*manually control AGT*/      
      AGT0->AGTMR2_b.LPM=0;
      while(0!=AGT0->AGTMR2_b.LPM);
      AGT0->AGTCR_b.TSTOP=1;
      while(0!=AGT0->AGTCR_b.TCSTF);      
      AGT0->AGTCR_b.TUNDF=0;
      MSTP->MSTPCRD_b.MSTPD3=1;
      SYSC->MSTPCRA_b.MSTPA22=1;
            
}
/***********************************************************************************************************************
* Function Name: trans_dstby
* Description  : transition to DSTBY mode with WUPT on
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void trans_dstby()
{
  int32_t gs_ret = 0;  
  
   /*show display*/
  trans_MIP_sequence(DSTBY,DSTBY1);
  
  /* Disable WUPT Module Stop */
  gs_ret =  R_LPM_FastModuleStart(LPM_FAST_MSTP_A_NONE, LPM_FAST_MSTP_B_NONE, LPM_FAST_MSTP_C_NONE, LPM_FAST_MSTP_D_WUPT); 
  if(0 != gs_ret){
    while(1);
  }  
   
  SYSC->PRCR = 0xA501;              /* PRCR0 is Disabled */
  SYSC->SCKDIVCR_b.PCKB=0;   
  SYSC->PRCR = 0xA500;              /* PRCR0 is Enabled */
    
  gs_ret = R_SYS_SystemClockSOSCSet();         /* set SOSC as System Clock */
  if(0 != gs_ret)
  {
    while(1);
  }    
  
  gs_ret=R_SYS_MainOscSpeedClockStop();	        /* Stop MOSC */
  if(0 != gs_ret)
  {
    while(1);
  }     

  /*start WUPT*/
  WUPT->TCR=0x90;
  
  gs_ret=R_LPM_DSTBYModeEntry(LPM_DSTBY_IO_KEEP);	        /* move to DSTBY */
  if(0 != gs_ret)
  {
    while(1);
  }      
        
}

/***********************************************************************************************************************
* Function Name: trans_sstby_vbb_minpwon
* Description  : transition to MINPWON VBB SSTBY mode
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void trans_sstby_vbb_minpwon()
{
  int32_t gs_ret = 0;  
  
  /*wait for SW2 press*/
  while(0!=PORT5->PIDR_b.PIDR08)
  {
    nop_func_sub();
  }
  
  R_SYS_SoftwareDelay(500, SYSTEM_DELAY_UNITS_MILLISECONDS);      /* prevent SW2 chattering*/
  
  trans_MIP_sequence(SSTBY_VBB_MINPWON,SSTBY_VBB_MINPWON1);
  
  SYSC->PRCR = 0xA501;              /* PRCR0 is Disable */
  SYSC->SCKDIVCR_b.PCKB=0;   
  SYSC->PRCR = 0xA500;              /* PRCR0 is Enabled */
    
  gs_ret = R_SYS_SystemClockSOSCSet();         /* set SOSC as System Clock */
  if(0 != gs_ret)
  {
    while(1);
  }    
  
  gs_ret=R_SYS_MainOscSpeedClockStop();	        /* Stop MOSC */
  if(0 != gs_ret)
  {
    while(1);
  }    
  
  PORT5->PDR_b.PDR08 = 1;             /* set port of SW for output */
  R_ICU_Pinset_CH4();                 /* IRQ interrupt enable */
  
  gs_ret=R_LPM_SSTBYModeEntry();	        /* move SSTBY MINPWON */
  if(0 != gs_ret)
  {
    while(1);
  }    
  
  R_ICU_Pinclr_CH4();                 /* IRQ interrupt disable */
  PORT5->PDR_b.PDR08 = 0;             /* set port of SW for input */
 
   R_SYS_SoftwareDelay(500, SYSTEM_DELAY_UNITS_MILLISECONDS);      /* prevent SW2 chattering*/
  R_SYS_MainOscSpeedClockStart();	        /* Started MOSC */
  while(1 != SYSC->OSCSF_b.MOSCSF){
    /* Waiting of MOSC oscillation stabilization */
  }
  
  gs_ret = R_SYS_SystemClockMOSCSet();         /* set MOSC as System Clock */
  if(0 != gs_ret){
    while(1);
  }
  
  return;
}
  

/***********************************************************************************************************************
* Function Name: trans_vbb_minpwon
* Description  : transition to MINPWON VBB OPE mode
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void trans_vbb_minpwon()
{
  int32_t gs_ret = 0;
   
  /*wait for SW2 press*/
  while(0!=PORT5->PIDR_b.PIDR08)
  {
    nop_func();
  }
  
  R_SYS_SoftwareDelay(500, SYSTEM_DELAY_UNITS_MILLISECONDS);      /* prevent SW2 chattering*/
  
  trans_MIP_sequence(VBB_MINPWON,VBB_MINPWON1);
    
  SYSC->PRCR = 0xA501;              /* PRCR0 is Disable */
  SYSC->SCKDIVCR_b.ICK = 0;        /* set PCLKB divition 1/1 */
  SYSC->SCKDIVCR_b.PCKB = 0;        /* set PCLKB divition 1/1 */
  SYSC->PRCR = 0xA500;              /* PRCR0 is Enable */
  
  R_LPM_PowerSupplyModeMinpwonSet();
  
  gs_ret = R_SYS_MediumSpeedClockStop();      /* Stopped MOCO */
  if(0 != gs_ret)
  {
    while(1);
  }
  
  gs_ret = R_SYS_SystemClockSOSCSet();	 /* set SOSC as System Clock */
  if(0 != gs_ret)
  {
    while(1);
  }  
  
  gs_ret = R_SYS_MainOscSpeedClockStop();      /* Stopped MOSC */
  if(0 != gs_ret)
  {
    while(1);
  }

      
  gs_ret=R_LPM_BackBiasModeEntry();          /* BackBiasModeEntry */
    if(0 != gs_ret)
  {
    while(1);
  }
}

/***********************************************************************************************************************
* Function Name: trans_minpwon
* Description  : transition to MINPWON mode
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void trans_minpwon()
{
  
  minpwon_state_t mode_minpwon = MINPWON1;
  bool mode_first_time=true;
  uint32_t vcom_count = 0;
  int32_t gs_ret = 0;
  
  while(1)
  {
    if((0==PORT5->PIDR_b.PIDR09)||mode_first_time)
    {
      /* proccess when pressed SW3 */   
      R_SYS_SoftwareDelay(500, SYSTEM_DELAY_UNITS_MILLISECONDS);      /* prevent chattering*/
      
      mode_first_time=false;      
      
      trans_MIP_sequence(MINPWON,mode_minpwon);
      
      R_LPM_PowerSupplyModeMinpwonSet();
      
      /*change clock*/
      switch(mode_minpwon)
      {
        /*MOSC 32 MHz*/
      case MINPWON1:
        SYSC->PRCR = 0xA501;              /* PRCR0 is Disable */
        
        SYSC->SCKDIVCR_b.ICK = 0;         /* ICLK 1/1 */ 
        while(SYSC->SCKDIVCR_b.ICK != 0);
        
        SYSC->PRCR = 0xA500;              /* PRCR0 is Enable */
        
        break;
        
      case MINPWON2:
        SYSC->PRCR = 0xA501;              /* PRCR0 is Disable */
        
        SYSC->SCKDIVCR_b.ICK = 1;         /* ICLK 1/2 */ 
        while(SYSC->SCKDIVCR_b.ICK != 1);
        
        SYSC->PRCR = 0xA500;              /* PRCR0 is Enable */
        
        break;
        
      case MINPWON3:
        SYSC->PRCR = 0xA501;              /* PRCR0 is Disable */
        
        SYSC->SCKDIVCR_b.ICK = 0;         /* ICLK 1/1 */ 
        while(SYSC->SCKDIVCR_b.ICK != 0);
        
        SYSC->PRCR = 0xA500;              /* PRCR0 is Enable */
        
        R_SYS_MediumSpeedClockStart();      /* Started MOCO */
        
        gs_ret = R_SYS_SystemClockMOCOSet(); 	/* set MOCO as System Clock */
        if(0 != gs_ret)
        {
          while(1);
        }
        
        gs_ret = R_SYS_MainOscSpeedClockStop();     /* Stop MOSC */
        if(0 != gs_ret)
        {
          while(1);
        }
        
        gs_ret = R_SYS_LowSpeedModeSet(); /* set low speedmode */           
        if(0 != gs_ret)
        {
          while(1);
        }  
        
        break;
        
      case MINPWON4:
        SYSC->PRCR = 0xA501;              /* PRCR0 is Disable */
        
        SYSC->SCKDIVCR_b.ICK = 1;         /* ICLK 1/2 */ 
        while(SYSC->SCKDIVCR_b.ICK != 1);
        
        SYSC->PRCR = 0xA500;              /* PRCR0 is Enable */
        
        gs_ret = R_SYS_SystemClockMOCOSet(); 	/* set MOCO as System Clock */
        if(0 != gs_ret)
        {
          while(1);
        }
        
        gs_ret = R_SYS_MainOscSpeedClockStop();     /* Stop MOSC */
        if(0 != gs_ret)
        {
          while(1);
        }
        
        gs_ret = R_SYS_LowSpeedModeSet(); /* set low speedmode */           
        if(0 != gs_ret)
        {
          while(1);
        }
        
        break;
        
      default: 
        break;
      }
      
      mode_minpwon++;
      if(mode_minpwon>MINPWON4)
      {
        mode_minpwon=MINPWON1;
      }
      
    }
    else if(0==PORT5->PIDR_b.PIDR08)
    {
      break;
    }
    
    /* adjust current composition */
    nop_func(); 
    
    /* proccess to prevent Screen burn-in */
    if(vcom_count > 1000)
    {
      SMIP_CFG_VCOM_PORT->PODR = (SMIP_CFG_VCOM_PORT->PODR ^ (1 << SMIP_CFG_VCOM_PIN));
      vcom_count = 0;
    }
    else
    {
      vcom_count++;
    }
  }  
  
  
}

/***********************************************************************************************************************
* Function Name: trans_allpwon
* Description  : transition to ALLPWON NORMAL mode
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void trans_allpwon()
{
  allpwon_state_t mode_allpwon = ALLPWON1;
  bool mode_first_time=true;
  uint32_t vcom_count = 0;
  int32_t gs_ret = 0;
  
  while(1)
  {
    if((0==PORT5->PIDR_b.PIDR09)||mode_first_time)
    {
      /* proccess when pressed SW3 */   
      R_SYS_SoftwareDelay(500, SYSTEM_DELAY_UNITS_MILLISECONDS);      /* prevent chattering*/
            
      trans_MIP_sequence(ALLPWON,mode_allpwon);
      
      /*change clock*/
      switch(mode_allpwon)
      {
        /*MOSC 32 MHz*/
      case ALLPWON1:
        
        R_SYS_MainOscSpeedClockStart(); /*Start MOSC*/
          while(1 != SYSC->OSCSF_b.MOSCSF)
          {
            /* Waiting of MOSC oscillation stabilization */
          } 
          
          gs_ret = R_SYS_SystemClockMOSCSet();	/* set MOSC as System Clock */
          if(0 != gs_ret)
          {
            while(1);
          }          
          
          SYSC->PRCR = 0xA501;              /* PRCR0 is Disable */
          SYSC->SCKDIVCR_b.ICK = 0;         /* ICLK 1/1 */ 
          while(SYSC->SCKDIVCR_b.ICK != 0);
          SYSC->PRCR = 0xA500 ;             /* PRCR0 is Enabled */
     
          
          /*stop HOCO*/
          if(true==mode_first_time)
          {
            mode_first_time=false;   
            SYSF->FLWT=0x00;
            
            /*change to HOCO 32 MHz*/
            /*change frequency to 32 MHz*/
            SYSC->PRCR=0xA501;
            SYSC->HOCOCR_b.HCSTP = 1U;
            
            if(3==SYSC->HOCOMCR_b.HCFRQ)
            {
              SYSC->HOCOMCR_b.HCFRQ=1;
            }
            
            SYSC->PRCR=0xA500;
          }
          
        gs_ret = R_SYS_HighSpeedModeSet(); /* set high speedmode */
        if(0 != gs_ret)
        {
          while(1);
        }          

        break;
        
      case ALLPWON2:
        SYSC->PRCR = 0xA501;              /* PRCR0 is Disable */
        
        SYSC->SCKDIVCR_b.ICK = 1;         /* ICLK 1/2 */ 
        while(SYSC->SCKDIVCR_b.ICK != 1);
        
        SYSC->PRCR = 0xA500;              /* PRCR0 is Enable */
        
        break;
        
      default: 
        break;
      }
      
      mode_allpwon++;
      if(mode_allpwon>ALLPWON2)
      {
        mode_allpwon=ALLPWON1;
      }
      
    }
    else if(0==PORT5->PIDR_b.PIDR08)
    {
      break;
    }
    
    /* adjust current composition */
    nop_func(); 
    
    /* proccess to prevent Screen burn-in */
    if(vcom_count > 1000)
    {
      SMIP_CFG_VCOM_PORT->PODR = (SMIP_CFG_VCOM_PORT->PODR ^ (1 << SMIP_CFG_VCOM_PIN));
      vcom_count = 0;
    }
    else
    {
      vcom_count++;
    }
  }

  
}


/***********************************************************************************************************************
* Function Name: trans_boost_allpwon
* Description  : transition to ALLPWON BOOST mode
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void trans_boost_allpwon()
{
  boostallpwon_state_t mode_boost = BOOST_ALLPWON1;
  bool mode_first_time=true;
  uint32_t vcom_count = 0;
  
  /*go from ALLPWON mode to BOOST mode*/  
  int32_t gs_ret = 0;
  
  gs_ret = R_SYS_BoostSpeedModeSet(); /* set boostspeedmode */
  if(0 != gs_ret)
  {
    while(1);
  }  
  SYSC->PRCR = 0xA501;              /* PRCR0 is Disabled */
  SYSC->SCKDIVCR_b.PCKB = 6;        /* set PCLKB division 1/64 */
  SYSC->PRCR = 0xA500;              /* PRCR0 is Enabled */
  
  
  while(1)
  {
    if((0==PORT5->PIDR_b.PIDR09)||mode_first_time)
    {
      /* proccess when pressed SW3 */   
      R_SYS_SoftwareDelay(500, SYSTEM_DELAY_UNITS_MILLISECONDS);      /* prevent SW2 chattering*/
      
      mode_first_time=false;      
      
      trans_MIP_sequence(BOOST_ALLPWON,mode_boost);      
      
      /*change clock*/
      switch(mode_boost)
      {
        /*HOCO 64 MHz*/
      case BOOST_ALLPWON1:           
        SYSF->FLWT=0x01;
        
        /*change to HOCO 64 MHz*/
        /*change frequency to 64 MHz*/
        SYSC->PRCR=0xA501;
        SYSC->HOCOCR_b.HCSTP = 1U;  
        SYSC->HOCOMCR_b.HCFRQ=3;
        SYSC->PRCR=0xA500;      
        
        break;
        
      case BOOST_ALLPWON2:
        R_SYS_MainOscSpeedClockStart(); /*Start MOSC*/
        while(1 != SYSC->OSCSF_b.MOSCSF)
        {
          /* Waiting of MOSC oscillation stabilization */
        } 
        
        gs_ret = R_SYS_SystemClockMOSCSet();	/* set MOSC as System Clock */
        if(0 != gs_ret)
        {
          while(1);
        }
        
        
        SYSF->FLWT=0x00;
        
        /*change to HOCO 32 MHz*/
        /*change frequency to 32 MHz*/
        SYSC->PRCR=0xA501;
        SYSC->HOCOCR_b.HCSTP = 1U;  
        SYSC->HOCOMCR_b.HCFRQ=1;
        SYSC->PRCR=0xA500;
        
        break;
        
      default: 
        break;
      }
      
      /*set HOCO as system clock*/
      SYSC->PRCR=0xA501;
      SYSC->HOCOCR_b.HCSTP = 0U;  
      
      while(1 != SYSC->OSCSF_b.HOCOSF)
      {
        /* Waiting of MOSC oscillation stabilization */
      } 
      
      SYSC->SCKSCR=0x00;      
      SYSC->PRCR=0xA500;
      
      R_SYS_MainOscSpeedClockStop(); /*Stop MOSC*/
      
      mode_boost++;
      if(mode_boost>BOOST_ALLPWON2)
      {
        mode_boost=BOOST_ALLPWON1;
      }
      
    }
    else if(0==PORT5->PIDR_b.PIDR08)
    {
      break;
    }
    
    /* adjust current composition */
    nop_func(); 
    
    /* proccess to prevent Screen burn-in */
    if(vcom_count > 1000)
    {
      SMIP_CFG_VCOM_PORT->PODR = (SMIP_CFG_VCOM_PORT->PODR ^ (1 << SMIP_CFG_VCOM_PIN));
      vcom_count = 0;
    }
    else
    {
      vcom_count++;
    }
  }
    
}

/***********************************************************************************************************************
* Function Name: make_img
* Description  : Update image data to be displayed in MIP LCD
* Arguments    : next_target: target power mode
*                next_target_ditail: target clock frequency
* Return Value : none
***********************************************************************************************************************/
void make_img(uint32_t next_target,uint32_t next_target_ditail){
      switch(next_target){
          case BOOST_ALLPWON:
                  switch(next_target_ditail){
                      case BOOST_ALLPWON1:
                          set_data(image_boostallpwon,SETLINE_MODE);    /* set MODE */
                          
                          set_data(image_HOCO,SETLINE_CLOCK);       /* set Clock */     
                          
                          set_data(image_ICLK_64MHz,SETLINE_ICLK);      /* set ICLK */
                          
                          set_data(image_pclkb_64,SETLINE_PCLKB);       /* set PCLKB */
                          
                          break;
                          
                      case BOOST_ALLPWON2:
                          set_data(image_ICLK_32MHz,SETLINE_ICLK);      /* set ICLK */
                          
                          break;
                          
                      default:
                          break;
                  }
                  break;
          case ALLPWON:
                  switch(next_target_ditail){
                      case ALLPWON1:
                          set_data(image_mode_allpwon,SETLINE_MODE);    /* set MODE */
                          
                          set_data(image_clock_mosc,SETLINE_CLOCK);   /* set Clock */
                          
                          set_data(image_ICLK_32MHz,SETLINE_ICLK);      /* set ICLK */

                          set_data(image_pclkb_64,SETLINE_PCLKB);       /* set PCLKB */
                        
                          break;
                      case ALLPWON2:
                          set_data(image_clock_mosc,SETLINE_CLOCK);   /* set Clock */
                          
                          set_data(image_clock_16MHz_DIV2,SETLINE_ICLK);/* set ICLK */
                        
                          break;

                      default:
                          break;
                  }
                  break; 
          case MINPWON:
                  switch(next_target_ditail){
                      case MINPWON1:
                          set_data(image_mode_minpwon,SETLINE_MODE);    /* set MODE */
                          
                          set_data(image_clock_moscHS,SETLINE_CLOCK);   /* set Clock */
                          
                          set_data(image_ICLK_32MHz,SETLINE_ICLK);      /* set ICLK */

                          set_data(image_pclkb_64,SETLINE_PCLKB);       /* set PCLKB */
                          
                          break;
                      case MINPWON2:
                          set_data(image_clock_moscHS,SETLINE_CLOCK);   /* set Clock */
                          
                          set_data(image_clock_16MHz_DIV2,SETLINE_ICLK);/* set ICLK */
                          
                          break;
                      case MINPWON3:
                          set_data(image_clock_mocoLS,SETLINE_CLOCK);   /* set Clock */
                          
                          set_data(image_clock_2MHz_DIV1,SETLINE_ICLK); /* set ICLK */
                          
                          break;
                      case MINPWON4:
                          set_data(image_clock_mocoLS,SETLINE_CLOCK);   /* set Clock */
                        
                          set_data(image_clock_1MHz_DIV2,SETLINE_ICLK); /* set ICLK */
                        
                          break;
                      
                      default:
                          break;
                  }
                  break; 
          case VBB_MINPWON:
                  set_data(image_mode_vbb_minpwon,SETLINE_MODE);        /* set MODE */
                          
                  set_data(image_clock_sosc,SETLINE_CLOCK);             /* set Clock */
                  
                  set_data(image_clock_32kHz,SETLINE_ICLK);             /* set ICLK */

                  set_data(image_pclkb_1,SETLINE_PCLKB);                /* set PCLKB */
            
                  break;
          case SSTBY_VBB_MINPWON:
                  set_data(image_mode_sstby_vbb_minpwon,SETLINE_MODE);    /* set MODE */

                  break;
          case DSTBY:                  
                  set_data(image_mode_dstby,SETLINE_MODE);        /* set MODE */
                          
                  set_data(image_clock_sosc_wupt,SETLINE_CLOCK);             /* set Clock */

            
                  break;
        
          default:
                  break;
      }
}


/***********************************************************************************************************************
* Function Name: set_data
* Description  : Overwrite each infomation(MODE,CLOCK,ICLK,PCLKB) for base image(bimg)
* Arguments    : target: image information of target mode
*                line: line to be changed
* Return Value : none
***********************************************************************************************************************/
void set_data(char target[],uint8_t line){
      uint32_t i = 0,datacount = 0;
      
      /* Overwrite each infomation(MODE,CLOCK,ICLK,PCLKB) for base image(bimg) */
      
      for(i = 0 + (37 * line); i < (814 + (37 * line)); i++){ /* (address:1byte +data:32byte + dummy:4byte + line) * 22   (line:140 or 167 or 194 or 221) */
          if((i%37) == 0){
            
              /* Do nothing */
            
          }else if(((i % 37) >= 1) && ((i % 37) <= 32)){
              bgimg[i] = target[datacount];
              datacount++;
          }else if((i % 37) >= 33){
            
              /* Do nothing */
          }
      }
}

/***********************************************************************************************************************
* Function Name: whole_process
* Description  : none
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void whole_process(){
  
  whole_state_t mode = BOOST_ALLPWON;
  while(0!=PORT5->PIDR_b.PIDR08);
  
      while(1)
      {
          switch(mode)
          {
              case BOOST_ALLPWON:
                  trans_boost_allpwon();
                  break;
              
              case ALLPWON:
                  trans_allpwon();
                  break;
              
              case MINPWON:
                  trans_minpwon();
                  break;
              
              case VBB_MINPWON:
                  trans_vbb_minpwon();
                  break;
              
              case SSTBY_VBB_MINPWON:
                  trans_sstby_vbb_minpwon();
                  break;
              case DSTBY:
                  trans_dstby();
                  break;
              default:
                  break;
          }
          
          if(mode !=  DSTBY)
          {
                mode++;          
          }else{
                mode = BOOST_ALLPWON;
          }
      }
}



/***********************************************************************************************************************
* Function Name: initialize
* Description  : none
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void initialize()
{
    volatile e_lpm_vbb_enable_status_t ret_vbb;
    st_lpm_sstby_cfg_t sstby_cfg;
    int32_t gs_ret = 0;
    int32_t result = SMIP_OK;

        
    
    if(LPM_VBB_ENABLED== R_LPM_BackBiasModeEnableStatusGet())
    {
      /* Stop VBB status */
      do
      {
        gs_ret = R_LPM_BackBiasModeDisable();
      }
      while ( 0 != gs_ret );
      
    }


    R_SYS_MainOscSpeedClockStart();     /* Started  MOSC oscillation */
    
    while(1 != SYSC->OSCSF_b.MOSCSF){
        /* Waiting of MOSC oscillation stabilization */
    }
   
    R_SYS_SoftwareDelay(2000, SYSTEM_DELAY_UNITS_MILLISECONDS);	/* Waiting of SOSC oscillation stabilization */
    
    gs_ret = R_LPM_BackBiasModeEnable(LPM_VBB_CLOCK_SOSC);	/* Enabled BackBiasMode */
    if(0 != gs_ret){
        while(1);
    }
    
    /* Setup SSTBY mode */
    sstby_cfg.power_supply    = LPM_OPE_TO_SSTBY_MINPWON_VBB;  /* Transit from ALLPWON OPE to MINPWON SSTBY*/
    sstby_cfg.speed          = LPM_SSTBY_SPEED_MODE_OFF;  /* Transit time is not shortened*/ 
    sstby_cfg.wup            = LPM_SSTBY_WUP_IRQ4;                   /* Wakeup interrupt : PORT_IRQ4 */
    gs_ret = R_LPM_SSTBYModeSetup(&sstby_cfg);
    
    
    /*set up IRQ4 interrupt (SW2 button)*/
  R_NVIC_ClearPendingIRQ(SYSTEM_CFG_EVENT_NUMBER_PORT_IRQ4);
  R_NVIC_SetPriority(SYSTEM_CFG_EVENT_NUMBER_PORT_IRQ4,3);
  R_NVIC_EnableIRQ(SYSTEM_CFG_EVENT_NUMBER_PORT_IRQ4);
  R_SYS_IrqEventLinkSet(SYSTEM_CFG_EVENT_NUMBER_PORT_IRQ4,0x13,NULL); 
  R_SYS_IrqStatusClear(SYSTEM_CFG_EVENT_NUMBER_PORT_IRQ4);
  
    
    /* Check VBB setup status */
    do
    {
        ret_vbb = R_LPM_BackBiasModeEnableStatusGet();
    }
    while ( LPM_VBB_ENABLED != ret_vbb );
      
    gs_ret = R_SYS_LowSpeedClockStop(); /* Stoped LOCO */
    if(0 != gs_ret){
        while(1);
    }
    
    SYSC->PRCR = 0xA501;                      /* PRCR0 is Disable */
    SYSC->SCKDIVCR_b.PCKB = 6;                /* set PCLKB divition 1/64 */
    SYSC->PRCR = 0xA500;                      /* PRCR0 is Enable */
    
    
    gs_ret = R_SYS_HighSpeedModeSet();		/* set HighSpeedMode as (NOMALMODE 32MHz) */
    if(0 != gs_ret){
        while(1);
    }
    
    gs_ret = R_SYS_SystemClockMOSCSet();	/* set MOSC as System Clock */
    if(0 != gs_ret){
        while(1);
    }
    
    R_SYS_MediumSpeedClockStop();               /* Stoped MOCO */
    
    
    /* Enabled ALL Module Stop */
    gs_ret =  R_LPM_FastModuleStop(LPM_FAST_MSTP_A_ALL, LPM_FAST_MSTP_B_ALL, LPM_FAST_MSTP_C_ALL, LPM_FAST_MSTP_D_ALL); 
    if(0 != gs_ret){
        while(1);
    }
        
    /*start SMIP*/
    /* Started  SMIP Driver */
    result = R_SMIP_Open(0, 2000000, &g_smip_tbl_lcd_info[SMIP_TYPE_KYOCERA], smip_cb);
    while(SMIP_OK != result);    
    
    result = R_SMIP_PowerOn();
    while(SMIP_OK != result);
        
    result =  R_SMIP_Suspend();               /* suspend SMIP driver */
    while(SMIP_OK != result);
    
    /* Initialize SW2 */
    PORT5->PDR_b.PDR08 = 0;
      
}

/**********************************************************************************************************************
* Function Name: BoardInit
* Description  : Configure board initial setting.
*                This function is called by SystemInit() function in system_RE01_256KB.c file.
*                This is reference to perform BoardInit process. Sample code of target is Evaluation Kit RE01 256KB
*                 on Renesas. Please modify this function to suit your board.
* Arguments    : none
* Return Value : none
**********************************************************************************************************************/
void BoardInit(void)
{
    /***** This function performs at beginning of start-up after released reset. *****/
    /***** Please set pins here if your board is needed pins setting at the device start-up. ****/
    /***** This function is suiting Evaluation Kit RE01 256KB. Please change the pin setting to suit your board. *****/
//
//    /* Handling of Unused ports (IOCVCC domain) */
//
//    /* PORT2 Setting */
//    /* Evaluation Kit RE01 256KB has DCDCs whose output is controlled by P208 and P209. */
//    /* Set P208 and P209 not to be used as DCDC_EN. (output low: Disable) */
//    /* It need to set P208 and P209 to enable DCDC when using EHC start-up of this device. */
//    /* Set P210 as LED0. (output high) */
//
//    /* PODR - Port Output Data
//       b15-b11  PODR15 - PORD11     - Output Low Level
//       b10      PODR10              - Output High Level
//       b9 -b0   PODR09 - PORD00     - Output Low Level */
//    PORT2->PODR = 0x0400;
//
//    /* PDR - Port Direction
//       b15-b11  PDR15 - PORD11      - Input
//       b10-b8   PDR10 - PORD08      - Output
//       b7 -b0   PDR07 - PORD00      - Input */
//    PORT2->PDR  = 0x0700;
//
//    /* PORT4 Setting */
//    /* Set P410 as LED1. (output high) */
//
//    /* PODR - Port Output Data
//       b15-b11  PODR15 - PORD11     - Output Low Level
//       b10      PODR10              - Output High Level
//       b9 -b0   PODR09 - PORD00     - Output Low Level */
//    PORT4->PODR = 0x0400;
//
//    /* PDR - Port Direction
//       b15-b11  PDR15 - PDR11       - Input
//       b10      PDR10               - Output
//       b9 -b0   PDR09 - PDR00       - Input */
//    PORT4->PDR  = 0x0400;

} /* End of function BoardInit */

/* End of File */
