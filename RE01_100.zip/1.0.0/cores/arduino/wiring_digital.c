#include "Arduino.h"


void pinMode(uint32_t pin, uint32_t mode)
{
  
}

void digitalWrite(uint32_t pin, uint32_t val)
{

}

int digitalRead(uint32_t pin)
{

  return 0;
}

