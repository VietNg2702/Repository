#ifndef RE01_CORE_H__
#define RE01_CORE_H__

#ifdef __cplusplus
extern "C" {
#endif  


void re01_core_init(void);


#ifdef __cplusplus
}
#endif
#endif